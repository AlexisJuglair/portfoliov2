/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_usermeta`; */
/* PRE_TABLE_NAME: `1642693011_wp_usermeta`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1642693011_wp_usermeta` (
  `umeta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1642693011_wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
1,
1,
'nickname',
'alexis'
/* VALUES END */
), (
/* VALUES START */
2,
1,
'first_name',
''
/* VALUES END */
), (
/* VALUES START */
3,
1,
'last_name',
''
/* VALUES END */
), (
/* VALUES START */
4,
1,
'description',
''
/* VALUES END */
), (
/* VALUES START */
5,
1,
'rich_editing',
'true'
/* VALUES END */
), (
/* VALUES START */
6,
1,
'syntax_highlighting',
'true'
/* VALUES END */
), (
/* VALUES START */
7,
1,
'comment_shortcuts',
'false'
/* VALUES END */
), (
/* VALUES START */
8,
1,
'admin_color',
'fresh'
/* VALUES END */
), (
/* VALUES START */
9,
1,
'use_ssl',
0
/* VALUES END */
), (
/* VALUES START */
10,
1,
'show_admin_bar_front',
'true'
/* VALUES END */
), (
/* VALUES START */
11,
1,
'locale',
''
/* VALUES END */
), (
/* VALUES START */
12,
1,
'wp_capabilities',
'a:1:{s:13:\"administrator\";b:1;}'
/* VALUES END */
), (
/* VALUES START */
13,
1,
'wp_user_level',
10
/* VALUES END */
), (
/* VALUES START */
14,
1,
'dismissed_wp_pointers',
''
/* VALUES END */
), (
/* VALUES START */
15,
1,
'show_welcome_panel',
0
/* VALUES END */
), (
/* VALUES START */
17,
1,
'wp_dashboard_quick_press_last_post_id',
4
/* VALUES END */
), (
/* VALUES START */
18,
1,
'wp_user-settings',
'mfold=o&libraryContent=browse&editor=html'
/* VALUES END */
), (
/* VALUES START */
19,
1,
'wp_user-settings-time',
1642685069
/* VALUES END */
), (
/* VALUES START */
21,
1,
'astra-sites-on-active',
'notice-dismissed'
/* VALUES END */
), (
/* VALUES START */
22,
1,
'session_tokens',
'a:1:{s:64:\"cd6d7ec94f00460df60863099d9860f62e6d8f0a1191d1c691fa11c38f008662\";a:4:{s:10:\"expiration\";i:1643703457;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:104:\"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Safari/537.36\";s:5:\"login\";i:1642493857;}}'
/* VALUES END */
), (
/* VALUES START */
23,
1,
'managenav-menuscolumnshidden',
'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'
/* VALUES END */
), (
/* VALUES START */
24,
1,
'metaboxhidden_nav-menus',
'a:3:{i:0;s:28:\"add-post-type-e-landing-page\";i:1;s:12:\"add-post_tag\";i:2;s:15:\"add-post_format\";}'
/* VALUES END */
), (
/* VALUES START */
25,
1,
'nav_menu_recently_edited',
5
/* VALUES END */
);
/* QUERY END */

