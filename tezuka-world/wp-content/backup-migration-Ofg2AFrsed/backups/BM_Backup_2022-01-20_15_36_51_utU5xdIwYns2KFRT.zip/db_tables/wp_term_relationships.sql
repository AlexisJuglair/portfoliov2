/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_term_relationships`; */
/* PRE_TABLE_NAME: `1642693011_wp_term_relationships`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1642693011_wp_term_relationships` (
  `object_id` bigint unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint unsigned NOT NULL DEFAULT '0',
  `term_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1642693011_wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES ( 
/* VALUES START */
1,
3,
0
/* VALUES END */
), (
/* VALUES START */
56,
2,
0
/* VALUES END */
), (
/* VALUES START */
57,
2,
0
/* VALUES END */
), (
/* VALUES START */
58,
2,
0
/* VALUES END */
), (
/* VALUES START */
59,
2,
0
/* VALUES END */
), (
/* VALUES START */
97,
3,
0
/* VALUES END */
), (
/* VALUES START */
101,
3,
0
/* VALUES END */
), (
/* VALUES START */
133,
4,
0
/* VALUES END */
), (
/* VALUES START */
134,
4,
0
/* VALUES END */
), (
/* VALUES START */
135,
4,
0
/* VALUES END */
), (
/* VALUES START */
224,
2,
0
/* VALUES END */
), (
/* VALUES START */
230,
2,
0
/* VALUES END */
), (
/* VALUES START */
243,
5,
0
/* VALUES END */
), (
/* VALUES START */
244,
5,
0
/* VALUES END */
), (
/* VALUES START */
245,
5,
0
/* VALUES END */
);
/* QUERY END */

